@echo off
python zNGL-Tool.py
pause
